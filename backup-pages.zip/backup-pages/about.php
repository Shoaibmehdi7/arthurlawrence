<link rel="stylesheet" href="../about_style.css">

<?php


include ('include/header.php');
?>
<title> About Us </title>
<link rel="canonical" href="https://www.arthurlawrence.net/about.php" />
<style>
    .about-fix{
        margin-bottom: 1rem;
    }
    @media screen and (max-width: 400px)
    {
        .row{
            margin: 0px;
        }

    }

    *, *::after, *::before {
        box-sizing: border-box;
    }

    body {
        font-family: sans-serif;
        color: #444444;
        background-color: #ffffff;
        margin: 0;
        padding: 0;
    }

    ul, ol {
        list-style-type: none;
        margin: 0;
        padding: 0;
    }

    .full-width-slider {
        position: relative;
        height: 100vh;
        overflow: hidden;
    }

    .slides {
        position: relative;
        height: 100%;
        background-color: dodgerblue;
    }

    .slides li {
        display: table;
        position: absolute;
        z-index: 1;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        transform: translateX(100%);
        transition: transform 0.5s;
        background-image: url("img/Integrity-new.png");
        background-size: cover;
        background-position: -14em 1px;
    }

    .slides li:nth-of-type(2) {
        background-image: url("img/Stewardship-new.png");
        background-size: cover;
    }

    .slides li:nth-of-type(3) {
        background-image: url("img/Value-Creation-new.png");
        background-size: cover;
    }

    .slides li:nth-of-type(4) {
        background-color: darkseagreen;
    }

    .slides li.selected {
        z-index: 2;
        transform: translateX(0);
    }

    .slides li.move-left {
        transform: translateX(-100%);
    }

    .slides li.visible {
        z-index: 2;
    }

    .slides li > div {
        display: table-cell;
        vertical-align: middle;
        text-align: center;
        color: #FFF;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }

    .slides h2 {
        margin-top: 0;
    }

    .slider-navigation a {
        position: absolute;
        z-index: 3;
        top: 50%;
        transform: translateY(-50%);
        left: 20px;
        height: 48px;
        width: 48px;
        color: #fff;
        text-decoration: none;
        font-weight: 100;
        opacity: 0.5;
        transition: opacity 0.3s, visibility 0.3s;
    }
    .slider-navigation a:hover {
        opacity: 1;
    }
    @media (max-width: 500px) {
        .slider-navigation a {
            display: none;
        }
    }

    .slider-navigation a.next {
        left: auto;
        right: 10px;
    }

    .slider-dots-navigation {
        position: absolute;
        z-index: 3;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
    }
    @media (max-width: 500px) {
        .slider-dots-navigation {
            display: none;
        }
    }

  

    .slider-dots-navigation li {
        display: inline-block;
        float: left;
        margin-right: 15px;
    }
    .slider-dots-navigation li:last-of-type {
        margin-right: 0;
    }

    .slider-dots-navigation a {
        display: block;
        height: 7px;
        width: 14px;
        border: 1px solid #FFF;
        overflow: hidden;
        white-space: nowrap;
        text-indent: 100%;
        color: transparent;
        transition: background-color 0.3s;
    }

    .slider-dots-navigation a:hover,
    .slider-dots-navigation a.selected {
        background-color: #FFF;
    }

    .visually-hidden img{
        width: 11.75em !important;
    }
    .sliderdiv {
        width: 45%;
    float: left;
    text-align: left !important;
    margin-top: 20vw;
    margin-left: 9vw;
    }
    .sliderP{
        font-size: 1.1em;
    line-height: 1.3em;
    font-weight: 500;
    }
    @media (max-width: 700px){
        .full-width-slider{
           height: 52vh;
        }
        .slides li{
                background-position: -23em 1px;
        }
        .sliderP{
            font-size: 0.8em;
   
        }
        .sliderdiv{
            margin-top: 30vw;
        }
        .headingslide{
         font-size: 1.5em;
    }
    .slider-navigation a{
        display: block !important;
    }
    }

  @media  only screen and (min-width: 701px) and (max-width: 1000px){
        .full-width-slider{
           height: 52vh;
        }
        .slides li{
                background-position: -23em 1px;
        }
        .sliderP{
            font-size: 0.8em;
   
        }
        .sliderdiv{
            margin-top: 30vw;
        }
        .headingslide{
         font-size: 1.5em;
    }
    .slider-navigation a{
        display: block !important;
    }
    .fl-rich-text{
        padding-bottom: 2em;
    }
    .fix-mobile-width{
        max-width: 100% !important;
        flex: 0 0 100%;

    }
    .fix-mobile-width p {
        margin-bottom: 3em;
    }
    .gray-color{
        margin-left: 0% !important;         
    }
    .pillarbox{
        max-width: 50%;
            flex: 0 0 48% !important;
    }
    .join-img ,.join-left{
       max-width: 100%;
        flex: 0 0 100% !important;
    }
    }

</style>
    <div id="page" class="site">
        <div id="content" class="site-content">
            <section class="full-width-slider">
                <ul class="slides">
                    <li class="selected">
                        <div  class="sliderdiv">
                            <h1 class="headingslide" style="color: white!important;font-weight: bold;">Improving Lives </h1>
                            <p class="sliderP">Creating a future that is inclusive, transparent and centered on social justice</p>
                        </div>
                    </li>
                    <li>
                        <div class="sliderdiv">
                            <h1 class="headingslide" style="color: white!important;font-weight: bold;">Stewardship </h1>
                            <p class="sliderP">Mobilizing thought leadership to build pathways for each new cohort of industry and social leadership.</p>
                        </div>
                    </li>
                    <li>
                        <div class="sliderdiv">
                            <h1 class="headingslide" style="color: white!important;font-weight: bold;">Value Creation  </h1>
                            <p class="sliderP">Pioneering the shift from business relationships to value streams. </p>
                        </div>
                    </li>
                </ul> <!-- .slides -->

                <ul class="slider-navigation">
                    <li><a href="#0" class="next">&rarr;</a></li>
                    <li><a href="#0" class="prev">&larr;</a></li>
                </ul>

                <ol class="slider-dots-navigation" style="opacity: 0">
                    <li><a href="#0" class="selected">1</a></li>
                    <li><a href="#0">2</a></li>
                    <li><a href="#0">3</a></li>
                </ol>
            </section> <!-- .full-width-slider -->

            <div style="padding-top: 120px;background-color: #F8F8F8;padding-bottom: 50px;">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="vc_row wpb_row vc_row-fluid vc_custom_1498582741584 p30"><div class="wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner"><div class="wpb_wrapper"><h2 style="font-size: 62px;font-weight: 700; line-height: 74px; text-align: left; visibility: visible; animation-name: fadeIn;" class="vc_custom_heading about-title wow fadeIn delay--1">Built To Excel</h2></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div>

                            <div class="vc_row wpb_row vc_row-fluid vc_custom_1498582659346  p30"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"><h5 style="font-size: 18px; text-align: left; visibility: visible; animation-name: fadeIn;" class="vc_custom_heading ls-1 wow fadeIn delay--2 vc_custom_1498738211316">Improving lives by creating exceptional value.</h5></div></div></div><div class="wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner"><div class="wpb_wrapper"><h3 style="color: #ee3429 ; text-align: left; visibility: visible; animation-name: fadeIn;" class="vc_custom_heading wow fadeIn delay--3">
                                               Management consulting is part science, part art. Arthur Lawrence adds mind and heart.
                                            </h3>
                                            <div class="wpb_text_column wpb_content_element  wow fadeIn delay--3" style="visibility: visible; animation-name: fadeIn;">
                                                <div class="wpb_wrapper  ">
                                                    <p>
                                                        What adds exceptional value is our approach. We employ thought leadership, process design, technology deployment and best practice to cover a wide realm of industry services.
                                                    </p>
                                                </div>
                                            </div>
                                        </div></div></div></div>
                        </div>
                    </div>
                </div>
            </div>
            <!--the content from AL site goes here-->



            <div class="fl-row-content-wrap vamtam-show-bg-image">
                <div class="fl-row-content fl-row-fixed-width fl-node-content">
                    <div class="fl-col-group fl-node-58f1282cb2dd4 fl-col-group-equal-height fl-col-group-align-center fl-col-group-responsive-reversed" data-node="58f1282cb2dd4">
                        <div class="fl-col fl-node-58f1282cb2e21 fl-col-small" data-node="58f1282cb2e21" data-progressive-animation="move-from-left" data-vamtam-animation-options="{&quot;type&quot;:&quot;immediate&quot;,&quot;origin&quot;:&quot;center center&quot;,&quot;exit&quot;:false,&quot;delay&quot;:-0.7,&quot;mobile&quot;:false,&quot;pin&quot;:false,&quot;pinTrigger&quot;:&quot;&quot;}" style="transform-origin: center center; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-vamtam-heading fl-node-58f1282cb2e60" data-node="58f1282cb2e60">
                                    <div class="fl-module-content fl-node-content">
                                        <h2 class="vamtam-heading ">
                                            <span class="vamtam-heading-text"><b>Thriving</b> in the talent economy</span>
                                        </h2>
                                    </div>
                                </div>
                                <div class="fl-module fl-module-rich-text fl-node-58f1282cb2e9d " data-node="58f1282cb2e9d">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="fl-rich-text">
                                            <p>
                                              Our employees are our most valuable resource. At Arthur Lawrence we are creating opportunities for passionate talent to lead organizations of the future      
                                            </p>
                                            <p>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="fl-module fl-module-vamtam-button fl-node-58f1282cb2ee1" data-node="58f1282cb2ee1">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="vamtam-button-wrap vamtam-button-width-auto" style="text-align:left">
                                            <a href="/talent.php"> <button type="button" class="btn btn-dark  btn-height" style="font-family: 'Montserrat', sans-serif !important; font-weight: bold; width: 150px; height: 50px;font-size: 12px;  ">LEARN MORE</button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="fl-col fl-node-58f1282cb2f24" data-node="58f1282cb2f24">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-photo fl-node-58f1283fdfb51" data-node="58f1283fdfb51">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="fl-photo fl-photo-align-right" itemscope="" itemtype="http://schema.org/ImageObject">
                                            <div class="fl-photo-content fl-photo-img-jpg">
                                                <img class="fl-photo-img wp-image-12028 size-full vamtam-lazyload-noparent image-loaded" src="./img/arturo.jpg"> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 2 images ends -->

            <div class="fl-row-content-wrap vamtam-show-bg-image">
                <div class="fl-row-content fl-row-fixed-width fl-node-content">
                    <div class="fl-col-group fl-node-58ee78aaa46c1 fl-col-group-equal-height fl-col-group-align-center" data-node="58ee78aaa46c1">
                        <div class="fl-col fl-node-58f13985701c0" data-node="58f13985701c0">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-photo fl-node-58f139856fdd3" data-node="58f139856fdd3">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="fl-photo fl-photo-align-center" itemscope="" itemtype="http://schema.org/ImageObject">
                                            <div class="fl-photo-content fl-photo-img-jpg">
                                                <img class="fl-photo-img wp-image-12027 size-full vamtam-lazyload-noparent image-loaded" src="./img/watch.jpg"> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="fl-col fl-node-58ee78aaa4705 fl-col-small fix-mobile-width" data-node="58ee78aaa4705" data-progressive-animation="move-from-right" data-vamtam-animation-options="{&quot;type&quot;:&quot;immediate&quot;,&quot;origin&quot;:&quot;center center&quot;,&quot;exit&quot;:false,&quot;delay&quot;:-0.7,&quot;mobile&quot;:false,&quot;pin&quot;:false,&quot;pinTrigger&quot;:&quot;&quot;}" style="transform-origin: center center; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-vamtam-heading fl-node-58ee78aaa47ee" data-node="58ee78aaa47ee">
                                    <div class="fl-module-content fl-node-content">
                                        <h2 class="vamtam-heading ">
                                            <span class="vamtam-heading-text"><b>Sustaining </b>value with consulting</span>
                                        </h2>
                                    </div>
                                </div>
                                <div class="fl-module fl-module-rich-text fl-node-58ee78aaa4832" data-node="58ee78aaa4832">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="fl-rich-text">
                                            <p>
                                               Quality serves as the most honest measure of management and technology consulting services, proudly led by Arthur Lawrence.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="fl-module fl-module-vamtam-button fl-node-59469e6f58a45 vamtam-button-flat" data-node="59469e6f58a45">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="vamtam-button-wrap vamtam-button-width-auto" style="text-align:left">
                                            <a href="/consulting.php"> <button type="button" class="btn btn-dark  btn-height" style="font-family: 'Montserrat', sans-serif !important; font-weight: bold; width: 150px; height: 50px;font-size: 12px;  ">LEARN MORE</button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ada-->


            <div class="fl-row-content-wrap vamtam-show-bg-image">
                <div class="fl-row-content fl-row-fixed-width fl-node-content">
                    <div class="fl-col-group fl-node-58f1282cb2dd4 fl-col-group-equal-height fl-col-group-align-center fl-col-group-responsive-reversed" data-node="58f1282cb2dd4">
                        <div class="fl-col fl-node-58f1282cb2e21 fl-col-small" data-node="58f1282cb2e21" data-progressive-animation="move-from-left" data-vamtam-animation-options="{&quot;type&quot;:&quot;immediate&quot;,&quot;origin&quot;:&quot;center center&quot;,&quot;exit&quot;:false,&quot;delay&quot;:-0.7,&quot;mobile&quot;:false,&quot;pin&quot;:false,&quot;pinTrigger&quot;:&quot;&quot;}" style="transform-origin: center center; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-vamtam-heading fl-node-58f1282cb2e60" data-node="58f1282cb2e60">
                                    <div class="fl-module-content fl-node-content">
                                        <h2 class="vamtam-heading ">
                                            <span class="vamtam-heading-text"><b>Delivering </b>solutions for scale</span>
                                        </h2>
                                    </div>
                                </div>
                                <div class="fl-module fl-module-rich-text fl-node-58f1282cb2e9d " data-node="58f1282cb2e9d">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="fl-rich-text">
                                            <p>
Our clients use our operational solutions to empower their growth. So we put the best minds at work to make best-in-class solutions a reality.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="fl-module fl-module-vamtam-button fl-node-58f1282cb2ee1" data-node="58f1282cb2ee1">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="vamtam-button-wrap vamtam-button-width-auto" style="text-align:left">
                                            <a href="/operations.php"> <button type="button" class="btn btn-dark  btn-height" style="font-family: 'Montserrat', sans-serif !important; font-weight: bold; width: 150px; height: 50px;font-size: 12px;  ">LEARN MORE</button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="fl-col fl-node-58f1282cb2f24" data-node="58f1282cb2f24">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-photo fl-node-58f1283fdfb51" data-node="58f1283fdfb51">
                                    <div class="fl-module-content fl-node-content">
                                        <div class="fl-photo fl-photo-align-right" itemscope="" itemtype="http://schema.org/ImageObject">
                                            <div class="fl-photo-content fl-photo-img-jpg">
                                                <img class="fl-photo-img wp-image-12028 size-full vamtam-lazyload-noparent image-loaded" src="./img/monily.jpg" > </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 2 images ends -->

            <!-- THE POWER OF COMMUNITY-->
            <div style="padding-top: 120px;;background-image:url('img/community.jpg'), linear-gradient(rgba(50,0,0,0.4),rgba(50,0,0,0.55));background-size:cover;background-blend-mode: overlay;opacity:0.5padding-bottom: 50px;">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="vc_row wpb_row vc_row-fluid vc_custom_1498582741584 p30"><div class="wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner"><div class="wpb_wrapper"><h2 style="color: #fafafa;    font-size: 3em;font-weight: 700; line-height: 1.2em; text-align: left; visibility: visible; animation-name: fadeIn;" class="vc_custom_heading about-title wow fadeIn delay--1">The Power of <br/> Community</h2></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div>

                            <div class="vc_row wpb_row vc_row-fluid vc_custom_1498582659346 p30"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper"><h5 style="color: #fafafa;font-size: 18px; text-align: left; visibility: visible; animation-name: fadeIn;line-height: 1.2em;" class="vc_custom_heading ls-1 wow fadeIn delay--2 vc_custom_1498738211316">How our exceptional people<br/>
                                                are valued at the organization</h5></div></div></div><div class="wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner"><div class="wpb_wrapper"><h3 style="color: rgb(222, 0, 46); text-align: left; visibility: visible; animation-name: fadeIn;" class=" white-small vc_custom_heading wow fadeIn delay--3">
                                                Digitization has blurred the lines between campuses, offices and the global workspace. We meet the needs of this new economy by internalizing learning as a process and as an outcome.
                                            </h3>
                                            <div class="wpb_text_column wpb_content_element  wow fadeIn delay--3" style="visibility: visible; animation-name: fadeIn;">
                                                <div class="wpb_wrapper" >
                                                    <p style="color: #fafafa;">
                                                        Our alumni have become successful change agents and service providers in technology consulting, management accounting, talent advocacy and more. </p>
                                                    <p style="color: #fafafa;">
                                                        They have led as innovation advisors, social leaders and even entrepreneurs. Many have been recognized as the best financial advisors and technology consultants in their competitive space.<br><br> We see their progress as an external return on our talent investment. <a href="#"> Learn more about the work of the Arthur Lawrence Alumni community.</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div></div></div></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- THE POWER ENDS-->


            <!-- leaders-->
         <!--    <div class="fl-row-content-wrap vamtam-show-bg-image" style="background: #F8F8F8;">
                <div class="fl-row-content fl-row-fixed-width fl-node-content">
                    <div class="fl-col-group fl-node-590a0b2c4f72b" data-node="590a0b2c4f72b">
                        <div class="fl-col fl-node-590a0b2c4f9d1 fl-col-has-cols" data-node="590a0b2c4f9d1">
                            <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                <div class="fl-module fl-module-vamtam-heading fl-node-590a0f7e549dc" data-node="590a0f7e549dc">
                                    <div class="fl-module-content fl-node-content" style="padding-top: 50px;">
                                        <h2 class="vamtam-heading ">
                                            <span class="vamtam-heading-text" style="color:#2e2e2e;"><b>Our Leadership</b></span>
                                        </h2>
                                    </div>
                                </div>
                                <div class="fl-col-group fl-node-590a0fca7eabb fl-col-group-nested fl-col-group-equal-height fl-col-group-align-top fl-col-group-custom-width" data-node="590a0fca7eabb">
                                    <div class="fl-col fl-node-590a0fca7edba fl-col-small" data-node="590a0fca7edba">
                                        <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                            <div class="fl-module fl-module-vamtam-team-member fl-node-590a0fdae7022" data-node="590a0fdae7022">
                                                <div class="fl-module-content fl-node-content">
                                                    <div class="team-member has-content">
                                                        <div class="thumbnail">
                                                            <a target=”_blank” href="https://www.linkedin.com/in/wajid-mirza-7a7366/" title="Wajid A. Mirza">
                                                                <div class="vamtam-responsive-wrapper image-loaded"><img width="650" height="720" src="./img/wm.jpg" class="attachment-full size-full"  data-orig-file="./img/wm.jpg" data-orig-size="650,720" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;0&quot;,&quot;iso&quot;:&quot;0&quot;,&quot;shutter_speed&quot;:&quot;0&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;0&quot;}" data-image-title="people-1" data-image-description="" data-medium-file="https://consulting.vamtam.com/wp-content/uploads/2016/04/people-1-451x500.jpg" data-large-file="./img/wm.jpg"></div> </a>
                                                          <!--   <div class="share-icons clearfix">
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                            </div> 
                                                        </div>
                                                        <div class="team-member-info">
                                                            <h5 class="regular-title-wrapper team-member-position">Managing Partner</h5>
                                                            <h3>
                                                                <a target=”_blank” href="https://www.linkedin.com/in/wajid-mirza-7a7366/" title="Wajid A. Mirza">
                                                                    Wajid A. Mirza</a>
                                                            </h3>
                                                            <div class="team-member-bio">
                                                                <p style="font-size: 13px;">Wajid A Mirza brings over two decades of experience in management and technology consulting, with a focus on enterprise strategy and business architecture, finance transformation and BI. His list of clients include Global 200 companies in utilities, energy, telecommunications, and consumer goods.</p> </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fl-col fl-node-590a0fca7ee0c fl-col-small" data-node="590a0fca7ee0c">
                                        <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                            <div class="fl-module fl-module-vamtam-team-member fl-node-590a124a72e0d" data-node="590a124a72e0d">
                                                <div class="fl-module-content fl-node-content">
                                                    <div class="team-member has-content">
                                                        <div class="thumbnail">
                                                            <a target=”_blank” href="https://www.linkedin.com/in/ilyasbaig/" title="Ilyas H. Baig">
                                                                <div class="vamtam-responsive-wrapper image-loaded">
                                                                    <img width="650" height="720" src="./img/ib.jpg">        </div> </a>
                                                            <!-- <div class="share-icons clearfix">
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                            </div> 
                                                        </div>
                                                        <div class="team-member-info">
                                                            <h5 class="regular-title-wrapper team-member-position">Senior Partner</h5>
                                                            <h3>
                                                                <a target=”_blank” href="https://www.linkedin.com/in/ilyasbaig/" title="Ilyas H. Baig">
                                                                    Ilyas H. Baig</a>
                                                            </h3>
                                                            <div class="team-member-bio">
                                                                <p style="font-size: 13px;">Ilyas H Baig is a change management specialist with largescale projects implemented in South Asia, MENA and North America. In a career spanning over 30 years, he led the turnaround of sick units to accelerate their journey towards profitability and revenue growth. At Arthur Lawrence, he has developed IT Distribution Centers across South Asia, leveraging Managed Services in F&A, HR, Health Management, I.T. and back office support solutions for Fortune 500 clients.</p> </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fl-col fl-node-590a0fca7ee57 fl-col-small" data-node="590a0fca7ee57">
                                        <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                            <div class="fl-module fl-module-vamtam-team-member fl-node-590a130c056d7" data-node="590a130c056d7">
                                                <div class="fl-module-content fl-node-content">
                                                    <div class="team-member has-content">
                                                        <div class="thumbnail">
                                                            <a target=”_blank” href="https://www.linkedin.com/in/bejal-bj-patel-249894/" title="Bejal Patel">
                                                                <div class="vamtam-responsive-wrapper image-loaded">
                                                                    <img width="650" height="720" src="./img/bj.jpg">         </div> </a>
                                                           <!--  <div class="share-icons clearfix">
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                                <a href="#"><span class="icon shortcode theme  use-hover" style=""></span></a>
                                                            </div> 
                                                        </div>
                                                        <div class="team-member-info">
                                                            <h5 class="regular-title-wrapper team-member-position">Partner</h5>
                                                            <h3>
                                                                <a  target=”_blank” href="https://www.linkedin.com/in/bejal-bj-patel-249894/" title="Bejal Patel">
                                                                    Bejal Patel</a>
                                                            </h3>
                                                            <div class="team-member-bio">
                                                                <p style="font-size: 13px;">Bejal “BJ” Patel began his career in talent acquisition and quickly rose to become the cofounder of one of the largest talent acquisition firms in Houston. During this period he built structures and processes within his firm, ROI Staffing, paving way for sustained revenue streams before returning to the client side.</p> </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- leaders end-->




            <div class="container-fluid content-section" style="padding-top:3em; padding-bottom: 3em">
                <div class="col-md-12 row">
                    <div class="col-md-5  vc_col-md-offset-1 from-bottom slide-in fix-mobile-width">
                        <div class="gray-color image-box"
                             style="box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12)!important; width: 100%;height:auto;">
                            <img src="img/world.jpg" alt="" class="img-responsive" style="
          background-repeat: no-repeat;"></div>
                    </div>
                    <div class="col-md-5  from-top slide-in fix-mobile-width" style="padding-left: 40px; padding-top: 0em;">
                        <h1
                            style="font-family: 'Montserrat', sans-serif !important; margin-top: 20px;">
                            Cultivating Specialties</h1>
                        <p style="font-family: 'Montserrat', sans-serif !important; font-size: 17px;">Responding to an ever-growing demand for specialized technical skills,<br/><br/> Arthur Lawrence launched a product designed exclusively towards identifying, testing and validating top technology talent.</p>
                        <a href="https://arthurlawrence.net/blog/arthur-lawrence-launches-xperti-an-elite-community-of-technology-professionals"> <button type="button" class="btn btn-dark  btn-height"
                                style="font-family: 'Montserrat', sans-serif !important; font-weight: bold; width: 150px; height: 50px;font-size: 12px;  ">LEARN MORE</button> </a>
                    </div>
                </div>
            </div>

            <!-- MEDIA HIGHLIGHTS-->

            <!-- MEDIA HIGHLIGHTS END-->

            <!--awards-->
            <div style="background:#F8F8F8;">
                <div class="container-fluid content-section" style="padding:10px 0px; width: 80%;">
                    <div class="row p30">
                        <div class="col-md-12">
                            <h1
                                style="font-family: 'Montserrat', sans-serif !important; margin-top: 20px;">
                                Our Accomplishments</h1>
                        </div>
                    </div>
                    <div class="row p30">
                        <div class="col-md-12">
                            <p>
                                Gracious acknowledgements by our industry peers and organizations.
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4  text-center" style="padding:50px;">
                            <img src="img/Inc-5000-logo.final.png" />
                            <p style="font-size: .9em;">Arthur Lawrence ranked within the Inc 5000 twice—in 2016 and 2017 as one of the fastest growing companies of America.</p>
<!--                             <a style="font-size: .9em;">LEARN MORE</a>
 -->                        </div>
                        <div class="col-md-4  text-center" style="padding:50px;">
                            <img src="img/hbj.png" />
                            <p style="font-size: .9em;">Ranked 25th in the HBJ’s Fast 100 Private Companies Award in 2017.</p>
<!--                             <a style="font-size: .9em;" href="https://arthurlawrence.net/blog/arthur-lawrence-wins-entrepreneur-360-award-for-2019/">LEARN MORE</a>
 -->                        </div>

                        <div class="col-md-4 text-center" style="padding:50px;">
                            <img src="img/iaop.png" />
                            <p style="font-size: .9em;">Named one of the top ten fastest growing businesses in Houston in 2017.</p>
<!--                             <a style="font-size: .9em;">LEARN MORE</a>
 -->                        </div>
                    </div>

                </div>


            </div>
            <!-- awards end-->


            <!-- 7 pillas-->

            <div class="container-fluid content-section" style="padding:100px 0px; width: 80%;">
                    <div class="row p30">
                    <div class="col-md-12 ">
                        <h1
                            style="font-family: 'Montserrat', sans-serif !important; margin-top: 20px;">
                            Our 'Seven Pillars'</h1>
                    </div>
                </div>
                <div class="row p30">
                    <div class="col-md-12">
                        <p>
                            Every company that succeeds has at its center a set of standards, of core beliefs and a vision. We rely on the seven core values that we believe enable us to deliver quality for our customers. Through strict adherence to these core values we have achieved success beyond all documented forecasts and anticipation.
                        </p>
                    </div>
                </div>

                <div class="row">
                    <div class=" col-md-3 pillarbox sel pillarbox-active" style="padding:27.5px !important;">

                        <h1>Education</h1>
                        <p style="font-size: .9em">Engineering breakthroughs with insights and new applications of skills and knowledge</p>

                    </div>

                    <div class="col-md-3 pillarbox secondary-sel" style="padding:30px !important;">
                        <h1>Integrity</h1>
                        <p style="font-size: .9em">Creating a future that is inclusive, transparent and centered on social justice.</p>

                    </div>

                    <div class="col-md-3 pillarbox secondary-sel" style="padding:30px !important;">
                        <h1>Value Creation</h1>
                        <p style="font-size: .9em">Pioneering the shift from business relationships to value streams.</p>

                    </div>
                    <div class="col-md-3 pillarbox secondary-sel" style="padding:30px !important;">
                        <h1>Collaboration</h1>
                        <p style="font-size: .9em">Prioritizing honesty, openness and a shared future with all our stakeholders, each time.</p>

                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3 pillarbox secondary-sel" style="padding:30px !important;">
                        <h1>Best Client</h1>
                        <p style="font-size: .9em">Prioritizing honesty, openness and a shared future with all our stakeholders, each time.</p>

                    </div>

                    <div class="col-md-3 pillarbox secondary-sel" style="padding:30px !important;">
                        <h1>Best People</h1>
                        <p style="font-size: .9em">Sustaining an environment that equips, nurtures and cultivates the best in our people</p>

                    </div>

                    <div class="col-md-3 pillarbox secondary-sel" style="padding:30px !important;">
                        <h1>Stewardship</h1>
                        <p style="font-size: .9em">Mobilizing thought leadership to build pathways across industry boundaries.               </p>

                    </div>
                    <!-- <div class="col-md-3" style="padding:50px;">

                        <p>Year after year, Accenture is recognized worldwide not only for business performance but also for inclusion and diversity.</p>

                    </div>  -->
                </div>

            </div>
            <!-- 7 pillas END-->
            <!-- MEDIA BEGIN


            <div class="container-fluid content-section" style="padding:100px 0px; width: 80%;">
                            <div class="row">
                                <div class="col-md-12">
                                <h1
                                            style="font-family: 'Montserrat', sans-serif !important; margin-top: 20px;">
                                            Media Highlights</h1>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p>
            Every company that succeeds has at its center a set of standards, of core beliefs and a vision. We rely on the seven core values that we believe enable us to deliver quality for our customers. Through strict adherence to these core values we have achieved success beyond all documented forecasts and anticipation.
                                    </p>
                                </div>
                            </div>

                         <div class="row blog">
                        <div class="col-md-12">
                          <div id="blogCarousel" class="carousel slide container-blog" data-ride="carousel">
                            <ol class="carousel-indicators">
                              <li data-target="#blogCarousel" data-slide-to="0" class="active"></li>
                              <li data-target="#blogCarousel" data-slide-to="1"></li>
                            </ol>

                            <div class="carousel-inner">
                              <div class="carousel-item active">
                                <div class="row">
                                  <div class="col-md-4 offset-md-2" >
                                    <div class="item-box-blog">
                                      <div class="item-box-blog-image">

                                        <figure> <img alt="" src="https://cdn.pixabay.com/photo/2017/02/08/14/25/computer-2048983_960_720.jpg"> </figure>
                                      </div>
                                      <div class="item-box-blog-body">

                                        <div class="item-box-blog-heading">
                                          <a href="#" tabindex="0">
                                            <h5>Recent developments around the organization 1</h5>
                                          </a>
                                        </div>

                                          <p><i class="fa fa-user-o"></i> Admin, <i class="fa fa-comments-o"></i> Comments(3)</p>
                                        </div> -->
            <!--Text
            <div class="item-box-blog-text">
              <p>Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor.</p>
            </div>
            <div class="mt"> <a href="#" tabindex="0" class="btn bg-blue-ui white read">read more</a> </div>
          </div>
        </div>
      </div>
    <div class="col-md-4" >
        <div class="item-box-blog">
          <div class="item-box-blog-image">

            <figure> <img alt="" src="https://cdn.pixabay.com/photo/2017/02/08/14/25/computer-2048983_960_720.jpg"> </figure>
          </div>
          <div class="item-box-blog-body">
            <div class="item-box-blog-heading">
              <a href="#" tabindex="0">
                <h5>Recent developments around the organization 1</h5>
              </a>
            </div>

            <div class="item-box-blog-text">
              <p>Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor.</p>
            </div>
            <div class="mt"> <a href="#" tabindex="0" class="btn bg-blue-ui white read">read more</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="carousel-item ">
    <div class="row">
      <div class="col-md-4 offset-md-2" >
        <div class="item-box-blog">
          <div class="item-box-blog-image">

            <figure> <img alt="" src="https://cdn.pixabay.com/photo/2017/02/08/14/25/computer-2048983_960_720.jpg"> </figure>
          </div>
          <div class="item-box-blog-body">

            <div class="item-box-blog-heading">
              <a href="#" tabindex="0">
                <h5>Recent developments around the organization 1</h5>
              </a>
            </div>

            <div class="item-box-blog-text">
              <p>Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor.</p>
            </div>
            <div class="mt"> <a href="#" tabindex="0" class="btn bg-blue-ui white read">read more</a> </div>

          </div>
        </div>
      </div>
      <div class="col-md-4" >
        <div class="item-box-blog">
          <div class="item-box-blog-image">

            <figure> <img alt="" src="https://cdn.pixabay.com/photo/2017/02/08/14/25/computer-2048983_960_720.jpg"> </figure>
          </div>
          <div class="item-box-blog-body">

            <div class="item-box-blog-heading">
              <a href="#" tabindex="0">
                <h5>Recent developments around the organization 1</h5>
              </a>
            </div>

            <div class="item-box-blog-text">
              <p>Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, adipiscing. Lorem ipsum dolor sit amet, consectetuer adipiscing. Lorem ipsum dolor.</p>
            </div>
            <div class="mt"> <a href="#" tabindex="0" class="btn bg-blue-ui white read">read more</a> </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</div>
</div>
</div>

</div>



Media End-->



              <section id="footer-sub">
                <div class="fade-in subscribe">
                    <div class="container-fluid">

                        <div class="col-md-12  row">
                           
                            <div class="col-md-6 col-sm-12 col-xs-12 small-text" style="margin-left: -5px;     left: 20px;">
                                <h4 style="font-family: 'Montserrat', sans-serif !important; letter-spacing: 0px !important;font-weight: lighter;margin-top: 5px;">Subscribe to stay updated with our latest thinking
                                </h4>
                            </div>

                            <div class="col-md-6 col-sm-12 col-xs-12 right">
                                <div class="row">
                                    <div class="col-md-8 col-sm-5 input-div"><input type="email" placeholder="YOUR EMAIL ADDRESS" id="input-type"></div>
                                    <div class="col-md-4 col-sm-7 ">
                                        <div class="wrapper-inner-tab-backgrounds-second mybtnsubscribe button-div" style="margin-top: -45px;">
                                            <div id="subButon" class="sim-button button6 mybtncolor" style="margin-top: 44px;margin-left: 0px; height: 45px !important;font-family: 'Montserrat', sans-serif !important;    width: 55%;" > 
                                                <span>Subscribe</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section>
                <div class="join-now">

                    <div class="col-md-12 row" style="    margin: 0px;padding: 0px;">
                        <div class="col-md-6 join-left from-left slide-in">
                            <p
                                style="font-family: 'Montserrat', sans-serif !important; font-size: 45px; color: black !important;">
                                <span style="font-weight: bolder">Join</span><br> Arthur Lawrence</p>
                            <p>Arthur Lawrence careers transform talent and potential into global opportunities. Invest your skills in building tomorrow's world. Be part of the future. Apply now at Arthur Lawrence.</p>

                              <div class="wrapper-inner-tab-backgrounds-second mybtnapplynow">
                                <div class="sim-button button6 mybtnapplynow1" style="    margin-top: 40px;    margin-left: 0px; border: 2px solid #2E2E2E; font-family: 'Montserrat', sans-serif !important; width: 71%;height: 45px;font-size: 13px;line-height: 42px;">
                                    <a target="_blank" href="http://jobs.arthurlawrence.net/Jobs/ERP_JobBoard.aspx"> <span>Apply now</span> </a>
                                </div>
                            </div>




                        </div>

<div class="col-md-6 join-img" style="padding: 0px;">
                <img src="  /img/suited.jpg" alt="join-img" class="img-fluid">
                <div class="join-hover">
                    <img src="images/andres.png" alt="join-hover img" class="w-25">
                </div>
            </div>


                    </div>

                </div>
            </section>







<?php

include('include/footer.php');
?>
            <script>
                (function(){
                    //define a slider object
                    function slider(element) {
                        this.element = element;
                        this.slides = this.element.querySelector('.slides').getElementsByTagName('li');
                        this.slidesNumber = this.slides.length;
                        this.arrowsNavigation = this.element.querySelector('.slider-navigation');
                        this.dotsNavigation = this.element.querySelector('.slider-dots-navigation');
                        this.dots = this.dotsNavigation.getElementsByTagName('a');

                        this.selectedSlide = 0;
                        this.prevSelectedSlide = 0;
                        this.intervalId;
                        //check if mouse is over the slide element
                        this.hovered = false;

                        this.bindEvents();
                        this.initAutoPlay();
                    }

                    slider.prototype.bindEvents = function() {
                        var self = this;
                        //detect click on arrows
                        this.arrowsNavigation.addEventListener('click', function(event){
                            if( event.target.tagName.toLowerCase() == 'a' ) {
                                event.preventDefault();
                                //determine new slide index
                                var newSlideIndex = ( event.target.classList.contains('next') )
                                    ? self.selectedSlide + 1
                                    : self.selectedSlide - 1;

                                self.showNewSlide(newSlideIndex);
                            }
                        });
                        //detect click on dots navigation
                        this.dotsNavigation.addEventListener('click', function(event){
                            if( event.target.tagName.toLowerCase() == 'a' ) {
                                event.preventDefault();
                                //determine new slide index
                                var newSlideIndex = elementIndex(event.target.parentElement);
                                self.showNewSlide(newSlideIndex);
                            }
                        });
                        //stop autoplay while hovering over the slider
                        this.element.addEventListener('mouseenter', function(){
                            self.hover = true;
                            clearInterval(self.intervalId);
                        });
                        //initialize autoplay when leaving the slider
                        this.element.addEventListener('mouseleave', function(){
                            self.hover = false;
                            self.initAutoPlay();
                        });
                    }

                    slider.prototype.initAutoPlay = function() {
                        var self = this;
                        this.intervalId = setInterval(function(){
                            self.showNewSlide(self.selectedSlide + 1);
                        }, 5000);
                    }

                    slider.prototype.showNewSlide = function(index) {
                        clearInterval(this.intervalId);
                        if( index < 0 ) index = this.slidesNumber - 1;
                        if( index > this.slidesNumber - 1 ) index = 0;
                        this.prevSelectedSlide = this.selectedSlide;
                        this.selectedSlide = index;

                        for( var i = 0; i < this.slidesNumber; i++) {
                            if( i < this.selectedSlide ) {
                                this.slides[i].classList.add('move-left');
                                this.slides[i].classList.remove('selected', 'visible');
                                this.dots[i].classList.remove('selected');
                            } else if( i == this.selectedSlide ) {
                                this.slides[i].classList.add('selected');
                                this.slides[i].classList.remove('move-left');
                                this.dots[i].classList.add('selected');
                            } else {
                                this.slides[i].classList.remove('selected', 'move-left', 'visible');
                                this.dots[i].classList.remove('selected');
                            }
                        }

                        this.slides[this.prevSelectedSlide].classList.add('visible');

                        if( !this.hover ) this.initAutoPlay();
                    }

                    function elementIndex(element) {
                        var siblings = element.parentElement.children;
                        for ( var i = 0; i < siblings.length; i++ ) {
                            if( siblings[i] == element ) return i;
                        }
                        return -1;
                    }

                    var sliders = document.getElementsByClassName('full-width-slider');
                    for( var i = 0; i < sliders.length; i++) {
                        (function(i){
                            new slider(sliders[i]);
                        }(i));
                    }
                })();
</script>
<script> 
$(document).ready(function(){

    $('.sel').hover(function(){
        $('.sel').addClass('pillarbox-active');
    });
     
      $('.secondary-sel').hover(function(){
        $(this).addClass('pillarbox-active');
         $('.sel').removeClass('pillarbox-active');
      });
       $('.secondary-sel').mouseleave(function(){
        $(this).removeClass('pillarbox-active');
         $('.sel').addClass('pillarbox-active');
      });

});

</script>