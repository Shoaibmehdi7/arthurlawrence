<?php include 'includes/header.php' ?>
<?php
// require 'connection.php';

// // Job Listing Filter and Default Listing

// $sql = "select t1.cat_id,t1.cat_title, cat_image, count(t2.fk_category) as totalJobs from job_categories t1 left join job_listing t2 ON t2.fk_category = t1.cat_id group by t1.cat_title";

// $result = mysqli_query($conn, $sql);
// $catList = array();

// if (mysqli_num_rows($result) > 0) {
//     while($row = mysqli_fetch_assoc($result)) {
//         array_push($catList, $row);
//     }
// } else {
//     $catList = [];
// }


// print_r($jobList);
// echo sizeof($jobList);
// die();
?>

    <!-- Navbar -- Start -->
    <?php include 'includes/navigation.php'; ?>
    <!-- Navbar -- End -->
    <!-- Page Content -- Start -->

    <header class="flex align-vert middle header-style-1">
        <div class="main-carousel animate__animated">
            <div class="item flex align-vert middle header-style-1">
                <img src="<?php echo $dir; ?>/assets/images/bg1.png" alt="" class="bg-image cross-small-bg">
                <img src="<?php echo $dir; ?>/assets/images/sliders/slider1.png" alt="" class="bg-image hide-m">
                <img src="<?php echo $dir; ?>/assets/images/sliders/slider1.png" class="bg-image-md hide-d" alt="">
                <div class="container align-hor edge middle">
                    <div class="col-7">
                        <h1 class="overlapping-text">Your <strong>Exceptional Career</strong> Begins Here</h1>
                        <p>Managing exceptional resources against exceptional opportunities</p>
                        <form class="flex align-vert middle gap-15 job-search-filter" action="<?php echo $dir; ?>/jobs/" method="post">
                            <div class="flex align-hor edge middle gap-10 job-search">
                                <div class="icon-input">
                                    <img src="<?php echo $dir; ?>/assets/images/loupe.png" class="inp-icon" alt="">
                                    <input type="text" name="title" placeholder="Job title or keyword">
                                </div>
                                <div class="icon-input">
                                    <img src="<?php echo $dir; ?>/assets/images/loupe.png" class="inp-icon" alt="">
                                    <input type="text" name="location" placeholder="Enter location">
                                </div>
                                <div class="flex align-hor right middle gap-10">
                                    <button class="button secondary big" type="submit" name="submit">Search</button>
                                    <button class="button secondary big" type="submit" name="view-all">View all jobs</button>
                                </div>
                            </div>
                            <div class="flex align-hor middle gap-15">
                                <div class="checkbox flex align-hor middle gap-5">
                                    <input type="checkbox" name="fullTime" value="Full Time"><label for="">Full Time</label>
                                </div>
                                <div class="checkbox flex align-hor middle gap-5">
                                    <input type="checkbox" name="partTime" value="Part Time"><label for="">Part Time</label>
                                </div>
                                <div class="checkbox flex align-hor middle gap-5">
                                    <input type="checkbox" name="remote" value="Remote"><label for="">Remote</label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section class="consultant-strip">
        <div class="container consult align-hor edge middle">
            <div class="col-6 flex align-vert left middle gap-15">
                <h2>Make <span class="text-primary bolder">your</span> search easy.
<!--                    <br><span class="bolder">Upload your resume</span>-->
                </h2>
                <p>Our Talent Specialists will get in touch with you!</p>
            </div>
            <div class="col-6 flex align-hor right middle">
                <div class="choose-file flex align-hor right middle gap-15">
                    <input type="file">
                    <button class="button blue invert big no-border">Submit</button>
                </div>
            </div>
        </div>
    </section>

    <section class="job-counter padding-y-50-lg">
        <div class="container flex align-vert middle center">
            <div class="flex align-vert middle center gap-20">
                <h2 class="text-white dense-text bold">Popular US Cities for Job Seekers</h2>
                <div class="flex align-hor middle center gap-20">
                    <div class="col-6">
                        <div class="progress pink">
                            <span class="progress-left">
                                <span class="progress-bar"></span>
                            </span>
                            <span class="progress-right">
                                <span class="progress-bar"></span>
                            </span>
                            <div class="progress-value">
                                <p>128</p>
                                <small>Houston, TX</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="progress yellow">
                            <span class="progress-left">
                                <span class="progress-bar"></span>
                            </span>
                            <span class="progress-right">
                                <span class="progress-bar"></span>
                            </span>
                            <div class="progress-value">
                                <p>163</p>
                                <small>Remote</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="padding-y-50-lg">
        <div class="container align-hor edge center">
            <div class="col-12 flex align-vert center middle gap-15">
                <h2>Explore jobs by categories</h2>
                <p>Choose your desired job from the categories below</p>
            </div>
            <div class="col-12">
                <div class="job-categories flex align-hor left stretch">
                    <?php // for ($i=0; $i < sizeof($catList); $i++) { ?>
                    <div class="category-box flex align-vert center middle gap-10">
                        <img src="<?php echo $dir; ?>/assets/<?php echo $catList[$i]['cat_image']; ?>" alt="">
                        <h3><?php // echo $catList[$i]['cat_title']; ?></h3>
                        <p><?php // echo $catList[$i]['totalJobs']; ?> Open Positions</p>
                        <a href="<?php // echo $dir; ?>/jobs/?id=<?php // echo $catList[$i]['cat_id']; ?>">View Jobs <i class="fa fa-arrow-right"></i></a>
                        <?php // if(!(($i+1)%3 == 0) && $i != 6 && $i != 7){ ?>
                        <span class="cateogry-dot"></span>
                        <?php // } ?>
                    </div>
                    <?php // } ?>
                </div>
            </div>
        </div>
    </section>

    <section class="padding-y-50-lg">
        <div class="container align-hor edge center">
            <div class="col-12 flex align-vert center middle gap-15">
                <h2>Our Blogs</h2>
            </div>
            <div class="col-12">
                <div class="blogs flex align-hor edge top gap-10">
                    <div class="blog-box flex align-vert center middle gap-10">
                        <img src="assets/images/blogs/blog1.png" class="blog-img" alt="">
                        <div class="blog-content flex align-vert left middle gap-10">
                            <div class="category-name"><span>Careers</span></div>
                            <a href="https://www.arthurlawrence.net/blog/business-process-management-bpm-life-cycle/">Understanding Business Process Management Lifecycle</a>
                            <p>Every organization, no matter big or small, has a business process that requires regular improvement. However, not all of them have access to the right tools and expertise to do so on their own, and without knowing how business process management (BPM) tools impact the lifecycle, they won’t be able to do so.</p>
                            <!-- <div class="author flex align-hor left middle gap-10">
                                <img src="assets/images/blogs/blogger/blogger.png" class="author-img" alt="">
                                <div class="author-detail flex align-vert left middle">
                                    <p>Peter Smith</p>
                                    <p class="opacity-5">May 18, 2021</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="blog-box flex align-vert center middle gap-10">
                        <img src="assets/images/blogs/blog2.png" class="blog-img" alt="">
                        <div class="blog-content flex align-vert left middle gap-10">
                            <div class="category-name"><span>Careers</span></div>
                            <a href="https://www.arthurlawrence.net/blog/talent-acquisition-strategy-employer-branding/">Show, Don’t Tell: What Role Does Employer Branding Play In Your Talent Acquisition Strategy?</a>
                            <p>Everyone wants to work at the best workplace and with the best people but, recruiters often forget that the talent is also trying to judge whether the company is the right fit for them. So, when it comes to finding the best quality of candidates, you also have to take into consideration that they’re also trying to find you.</p>
                            <!-- <div class="author flex align-hor left middle gap-10">
                                <img src="assets/images/blogs/blogger/blogger.png" class="author-img" alt="">
                                <div class="author-detail flex align-vert left middle">
                                    <p>Peter Smith</p>
                                    <p class="opacity-5">May 18, 2021</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="blog-box flex align-vert center middle gap-10">
                        <img src="assets/images/blogs/blog3.png" class="blog-img" alt="">
                        <div class="blog-content flex align-vert left middle gap-10">
                            <div class="category-name"><span>Careers</span></div>
                            <a href="https://www.arthurlawrence.net/blog/digital-transformation-trends/">Top Digital Transformation Trends For 2021</a>
                            <p>Digital transformation is no longer just a buzzword – it has become a necessity. As organizations scurried to respond to real-time risks during the onset of the pandemic, many had to take drastic measures to either revamp their business model or implement a digital transformation strategy immediately.</p>
                            <!-- <div class="author flex align-hor left middle gap-10">
                                <img src="assets/images/blogs/blogger/blogger.png" class="author-img" alt="">
                                <div class="author-detail flex align-vert left middle">
                                    <p>Peter Smith</p>
                                    <p class="opacity-5">May 18, 2021</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="blog-box flex align-vert center middle gap-10">
                        <img src="assets/images/blogs/blog4.png" class="blog-img" alt="">
                        <div class="blog-content flex align-vert left middle gap-10">
                            <div class="category-name"><span>Careers</span></div>
                            <a href="https://www.arthurlawrence.net/blog/specialized-staffing-solutions-helps-businesses-grow/">How Do Businesses Benefit From Partnering With a Specialized Staff Agency?</a>
                            <p>Specialized staffing services have enabled businesses in healthcare and tech industries with finding the right talent – and faster. These industries are evolving rapidly and becoming integral to the business landscape, hence the demand for talent increases regularly.</p>
                            <!-- <div class="author flex align-hor left middle gap-10">
                                <img src="assets/images/blogs/blogger/blogger.png" class="author-img" alt="">
                                <div class="author-detail flex align-vert left middle">
                                    <p>Peter Smith</p>
                                    <p class="opacity-5">May 18, 2021</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="padding-y-50-lg">
        <div class="container align-vert edge center gap-50">
            <div class="col-12 flex align-vert center middle gap-15">
                <h2>Our Accomplishments</h2>
            </div>
            <div class="col-12">
                <div class="accomplishments flex align-hor center middle gap-20">
                    <img src="assets/images/accomplishments/accomplishment1.png" alt="">
                    <img src="assets/images/accomplishments/accomplishment2.png" alt="">
                    <img src="assets/images/accomplishments/accomplishment3.png" alt="">
                    <img src="assets/images/accomplishments/accomplishment4.png" alt="">
                    <img src="assets/images/accomplishments/accomplishment5.png" alt="">
                    <img src="assets/images/accomplishments/accomplishment6.png" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="contact-us padding-y-50-lg">
        <div class="container align-hor edge center">
            <div class="col-4 flex align-vert center middle gap-15">
                <div class="col-12 flex align-vert left middle gap-15">
                    <h2>Get in touch with our <br>
                        Expert Recruiters <span class="text-primary">NOW!</span></h2>
                    <p class="section-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua

                        Ut enim ad minim veniam, quis nostrud exercitation</p>
                    <div class="flex align-vert left middle gap-15">
                        <div class="contact-info-box flex align-hor left middle gap-15">
                            <span class="icon-border">
                                <div class="icon">
                                    <img src="assets/images/live-chat.png" alt="">
                                </div>
                            </span>
                            <div class="contact-content">
                                <p class="info-heading">Recruiters writing:</p>
                                <p>Live Chat</p>
                            </div>  
                        </div>
                        <div class="contact-info-box flex align-hor left middle gap-15">
                            <span class="icon-border">
                                <div class="icon green">
                                    <img src="assets/images/email.png" alt="">
                                </div>
                            </span>
                            <div class="contact-content">
                                <p class="info-heading">Send us at:</p>
                                <p>resume@arthurlawrence.net</p>
                            </div>  
                        </div>
                        <div class="contact-info-box flex align-hor left middle gap-15">
                            <span class="icon-border">
                                <div class="icon">
                                    <img src="assets/images/phone.png" alt="">
                                </div>
                            </span>
                            <div class="contact-content">
                                <p class="info-heading">Call us now:</p>
                                <p>+1 (213) 493 6482</p>
                            </div>  
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-7 contact-form align-vert middle center">
                <form action="email.php" method="post" class="flex align-vert top stretch gap-15">
                    <div class="form-box flex align-hor edge middle gap-15">
                        <div class="form-field">
                            <label for="jobTitle">Job Title<span class="text-primary">*</span></label>
                            <input type="text" name="jobTitle" placeholder="Type here">
                        </div>
                        <div class="form-field">
                            <label for="fullName">Full Name<span class="text-primary">*</span></label>
                            <input type="text" name="fullName" placeholder="Type here">
                        </div>
                    </div>
                    <div class="form-box flex align-hor edge middle gap-15">
                        <div class="form-field">
                            <label for="email">Email<span class="text-primary">*</span></label>
                            <input type="email" name="email" placeholder="Type here">
                        </div>
                        <div class="form-field">
                            <label for="phone">Phone<span class="text-primary">*</span></label>
                            <input type="text" name="phone" placeholder="Type here">
                        </div>
                    </div>
                    <div class="form-box flex align-hor edge middle gap-15">
                        <div class="form-field">
                            <label for="location">Location<span class="text-primary">*</span></label>
                            <input type="text" name="location" placeholder="Type here">
                        </div>
                        <div class="form-field">
                            <label for="citizenship">Citizenship<span class="text-primary">*</span></label>
                            <select name="citizenship" name="citizenship">
                                <option value="H1B">H1B</option>
                            </select>
                        </div>
                    </div>
                    <div class="flex align-hor edge middle gap-15">
                        <div class="form-field choose-file">
                            <label for="resume">Upload your resume<span class="text-primary">*</span></label>
                            <input type="file" name="resume" id="resume" placeholder="Type here">
                        </div>
                    </div>
                    <div class="flex align-hor edge middle gap-15">
                        <button class="button secondary big form-btn" name="submit" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </section>


    <script>
        $(document).ready(function(){
            // $('#myTable').DataTable();
            $(".blog-content a").matchHeight();
        });
    </script>

<?php include 'includes/footer.php' ?>