<?php include 'includes/header.php' ?>

    <!-- Navbar -- Start -->
    <?php include 'includes/navigation.php'; ?>
    <!-- Navbar -- End -->
    <!-- Page Content -- Start -->

    <style>
        .pt-150  {padding-top: 150px; }
    </style>




    <section class="contact-us padding-y-50-lg pt-150">
        <div class="container align-hor edge center">
            <div class="col-12 flex align-vert center middle gap-15">
                <h1>This is Dashboard</h1>
            </div>
        </div>
    </section>


    <script>
        $(document).ready(function(){
            // $('#myTable').DataTable();
            $(".blog-content a").matchHeight();
        });
    </script>

<?php include 'includes/footer.php' ?>