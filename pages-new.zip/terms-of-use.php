<?php
include ('include/header.php');
?>
<style>
    .img-txt h4{
        color: white;
        font-size: 1.2em;
    }
    #banner::before{
        background: rgba(0, 0, 0, 0) !important;
    }

.h1, h1 {
    font-size: 2rem;
}
p{
        font-size: 1em;
}
ul, li {
    font-size: 16px;
}
</style>

<!-- ========= banner section start ======= -->
<section id="banner" style="background-image: url('img/terms-min.jpg')">
    <div class="bnr-cont">
        <div class="container text-center">
               <h1>Terms of Use</h1>
           
        </div>
    </div>
</section>
<!-- ========= end of banner section ======= -->

<!-- ====== intro section start  ======= -->
<section id="intro">
    <div class="container">
        <div class="row py-lg-5">
            <div class="col-md-12 intro-txt">
                <p class="p mb-4">
                <h1>Terms of Use</h1>
<p class="privacy">By using, accessing and browsing this site, you agree and accept the following terms and conditions, without any limitations and qualification.</p>
<p class="privacy">Unless stated otherwise the contents, including but not limited to, the text, the images, the narrations, reviews contained herein with the arrangements are the sole property of Arthur Lawrence. All the trademarks used and displayed within the site are the rightful property of their respective owners.</p>
<p class="privacy">Nothing in this website shall be deemed and construed as rights and/or permission, implication, estoppel or otherwise any license or right to copyrights, patent, trademark or other proprietary interest of Arthur Lawrence or any other entity. This site and content within the site, including but not limited to texts, images, html code(s), buttons and other incorporated, implicit and explicit features, may not be copied, distributed, refurbished, reproduced, republished, transmitted, uploaded, distributed and redistributed, posted in any way, without the prior consent and permission issued in written by Arthur Lawrence; except that the user and you may download, display and print any one copy of the materials on any single computer system with the purpose solely for your personal, non-commercial use, with the condition that the material is maintained in its original form and not changed in any way and you keep intact all copyrights, trademarks, and other proprietary notices.</p>
<p class="privacy">The content and the information contained within the site is available for free of charge and only for informational and educational purposes and shall not create a business or professional service level relationship between the user and Arthur Lawrence on this or through this site. Links and connections on the site may lead to services and sites not directly operated by Arthur Lawrence or managed totally by third party companies. Arthur Lawrence takes no compensatory responsibility for any such third party sites and / or services. No further warranty, judgment, and /or guarantee shall be provided and made with respect to such other services or site and Arthur Lawrence is not responsible for any activity on the sites and the services. Any use or misuse of the information you&rsquo;ve provided to such sites and services will not hold Arthur Lawrence liable in any way and that which will be at user&rsquo;s own risk and discretion.</p>
               
            </div>
            
        </div>
    </div>
</section>
<!-- ====== //end of intro section ======= -->

<!-- ===== capability section start ===== -->

<!-- ===== // end of capability section  ===== -->

<!-- ==== case study section start ==== -->

<!-- ====== contact form ===== -->

<!-- ===== // end of join section ====== -->


<?php
include ('include/footer.php');
?>

