



<style type="text/css">
  .bulletpoint{
    font-size: 22px;
    margin-left: .3em;
  }
  .bullclass{
    font-size: 11px;
  }
  a{color: inherit;}
 a:visited, a:hover, a:focus, a:active{
    color: inherit;
  }
</style>
<section style="margin-top: -1px;">
    <footer>

        <div class="fade-in footer">
            <div class="container-fluid footer-height" style="width: 88%; ">
               
                <div class="col-md-12 row">
                    <div class="col-md-12 col-sm-12 footer-para" style="line-height: 28px;text-align: center;">
                        <img src="../img/logowhite.png" class="img-responsive imagezoom" width="20%">
                        <p style="
                            font-family: 'Montserrat', sans-serif !important;
    margin-top: 0;
    color: white;
    margin-bottom: 3px;
    float: left;
    width: 100%;
    ">Our future-first approach is fundamentally based on our vision to improves lives. Subscribe today to learn more about our impact.</p>
 <div class="col-md-12    col-xs-12 " style="margin-top: -9px;     text-align: center;">
  <p style="font-size: 13px;display: inline-flex;"> Follow us : </p>
                          <a href="https://www.linkedin.com/company/arthur-lawrence/"><i class="fab fa-linkedin-in"></i></a>
                        <a href="https://www.facebook.com/arthurlawrenceworldwide"><i class="fab fa-facebook-f"></i></a>

                        <a href="https://twitter.com/arthurlawrence_"><i class="fab fa-twitter"></i></a>

                        <a href="https://www.youtube.com/user/arthurlawrenceus"><i class="fab fa-youtube"></i></a>

                    </div>

                        <div class="about-fix" style="width: 100%;margin-top: -14px;">
                          <span class="bullclass"><span class="bulletpoint">&#8226;</span> <a href="http://jobs.arthurlawrence.net/Jobs/ERP_JobBoard.aspx" style="color: inherit;">Careers</a></span>
                           <span class="bullclass"><span class="bulletpoint">&#8226;</span> <a href="/contact.php" style="color: inherit;"> Contact us</a></span>
                            <span class="bullclass"><span class="bulletpoint">&#8226;</span> <a href="/privacy-policy.php" style="color: inherit;"> Privacy policy</a> </span>
                           <span class="bullclass"><span class="bulletpoint">&#8226;</span> <a href="/corporate-responsibility.php" style="color: inherit;"> Corporate Responsibility</a> </span>
                           <span class="bullclass"><span class="bulletpoint">&#8226;</span> <a href="/terms-of-use.php" style="color: inherit;">Terms of use</a></p></span>
                         </div>
                        <p class="copy-rights" style="font-family: 'Montserrat', sans-serif !important;font-size: 11px;margin-top: -20px;">Copyrights (c) 2021 Arthur Lawrence
                        <p>
                    </div>



            </div>
        </div>

    </footer>
</section>

</div>
</div>
<!--integrating the original page -->



  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>


<!--googleon: all-->
<!-- <script type="text/javascript" href="../js/bootstrap.js"></script>
<script type="text/javascript" href="../js/bootstrap.min.js"></script>
 -->
<script src="../css/app.part.836cf2f7fb4e484770fd.js.download"></script>
<script src="../js/runtime.197ce4f62dc8d6578fc0.js"></script>
<script src="../js/shared.part.963e08d887e09051a717.js"></script>
<script src="../js/app.part.b3d3e60ae9d833d5a244.js"></script>

<div id="aria-help-live" class="visually-hidden" aria-live="polite"></div>
<div id="modal-root-blog"></div>

<!--integrating the original page2 -->

</body>

</html>