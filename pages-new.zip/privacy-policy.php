<?php
include ('include/header.php');
?>
<style>
    .img-txt h4{
        color: white;
        font-size: 1.2em;
    }
    #banner::before{
        background: rgba(0, 0, 0, 0) !important;
    }

.h1, h1 {
    font-size: 2rem;
}
p{
        font-size: 1em;
}
ul, li {
    font-size: 16px;list-style: disc;
}
</style>

<!-- ========= banner section start ======= -->
<section id="banner" style="background-image: url('img/privacy-min.jpg')">
    <div class="bnr-cont">
        <div class="container text-center">
            <h1>Privacy Policy</h1>
           
        </div>
    </div>
</section>
<!-- ========= end of banner section ======= -->

<!-- ====== intro section start  ======= -->
<section id="intro">
    <div class="container">
        <div class="row py-lg-5">
            <div class="col-md-12 intro-txt">
                <p class="p mb-4">
                    <h1>Privacy Policy</h1>
<p class="privacy">We believe in protecting your privacy on every level. While you browse the internet and our website we collect information regarding the way readers use our website. This helps us draw conclusions on usage patterns which will enable us to make any necessary changes to make your browsing experience the best it can be. Technically speaking, this information will be recorded through &ldquo;smart cookies&rdquo; which store temporary yet vital information which will guide us toward a more improved user experience.</p>
<h3>Contact Information</h3>
<p class="privacy">In order to provide our website functions in a safe and secure environment the site shall collect personal information from its registered users. This enables us to do the following:</p>
<ul class="content-privacy">
<li>Provide access for site services including customer service and support</li>
<li>Provide transaction and informational services</li>
<li>Prevent illegal use of the site and any activities that may infringe on the Terms and Conditions of Use</li>
<li>Develop customized services to aid in site efficiency and user satisfaction</li>
</ul>
<h3>Sharing of Information</h3>
<p class="privacy">The owners of this site may access the personal information of its registered users for the following:</p>
<ul class="content-privacy">
<li>Assurance of compliance of regulatory laws in all jurisdictions</li>
<li>Provide and supply to third parties and site partners contact information for use in promotions and auxiliary service offers</li>
<li>Ensure the proper and continued services of the site and its associated services</li>
<li>Improve the services of the site for its users</li>
<li>Perform research and marketing analysis to aid in continuous improvement</li>
<li>Prevent illegal and prohibited usage of the site</li>
<li>Any other purpose or requirement needed for site associations in joint ventures, mergers or in the event the site is purchased by another entity</li>
</ul>
<h3>Using Cookies</h3>
<p class="privacy">Cookies are the preferred method of the site servers to send and retrieve information on the users&rsquo; browsers, but not necessarily information regarding the system being utilized by the user. Cookies store information about user preferences, input field information and website usage patterns. This better enables us to customize the future utility of the website for a better user experience. Our server sends a text file to the browser the user is utilizing to access the site. The server logs the user behavior, frequency and characteristics of site traffic. Some browsers may not be enabled to allow the cookies to function properly, which may improperly change the capabilities of the site for the user.</p>
<h3>Log Files</h3>
<p class="privacy">This website uses IP addresses which help track trends, user movements, and user demographics. IP addresses are not in any way connected with personal identifying information.</p>
<h3>Links</h3>
<p class="privacy">The privacy policy stated herein is only applicable to this site and any affiliated and authorized persons representing this site. Any other third-party links available on the site are not endorsed, verified or guaranteed by the site administrators. It is strongly suggested that you read the privacy policy of any third-party websites before leaving our secure site. This site is not responsible for any consequences occurring directly or indirectly experienced by the user while accessing any third-party websites.</p>
<h3>Security</h3>
<p class="privacy">Data transmission over the internet is never 100% guaranteed to be safe, whether the transmission is transactional or personal in nature. The owners of this site cannot guarantee the security of data transmission of any kind while browsing the site.</p>
<p class="privacy">Thank you for visiting our website. We welcome any suggestions or feedback on any of our services to enable us to better serve our customers. To contact us, please complete the Contact Us form and we will be more than happy to assist you.</p>
                </p>
               
            </div>
            
        </div>
    </div>
</section>
<!-- ====== //end of intro section ======= -->

<!-- ===== capability section start ===== -->

<!-- ===== // end of capability section  ===== -->

<!-- ==== case study section start ==== -->

<!-- ====== contact form ===== -->

<!-- ===== // end of join section ====== -->


<?php
include ('include/footer.php');
?>

