<?php
include ('include/header.php');
?>
<link rel="canonical" href="https://www.arthurlawrence.net/services.php" />
<style>

    .img-txt h4{
        color: white;
        font-size: 1.2em;
    }
    #banner::before{
        background: rgba(0, 0, 0, 0) !important;
    }
h3{
     text-align: left !important;
     letter-spacing: 0px !important    ;
     font-family: inherit !important;
  text-transform: capitalize !important;
 
}
</style>

<!-- ========= banner section start ======= -->
<section id="banner" style="background-image: url('img/Services.jpg')">
    <div class="bnr-cont">
        <div class="container text-center">
             <h1>How we help businesses</h1>
            <p>Leading with a future first approach to transforming businesses</p>
        </div>
    </div>
</section>
<!-- ========= end of banner section ======= -->

<!-- ====== intro section start  ======= -->
<section id="intro">
    <div class="container">
        <div class="row py-lg-5 mt-5">
            <div class="col-md-7 intro-txt">
                <h2 class="h2 mb-2">Architects of service excellence</h2>
                <p class="p mb-4">
                    We are in the business of helping organizations aim higher and achieve more - so they are better positioned to give back to the development of their communities. Everyday, we are pioneering the cutting-edge in the intersection of technology, business strategy and operational performance so we can lead our clients towards a sustainable future.
                </p>
                <h3 class="h3 mb-2">Leading by being exceptional</h3>
                <p class="p mb-4">
                   At Arthur Lawrence, we believe that the right people are the most powerful catalysts behind progress in any organization. By carefully curating skill-based communities that rely on industry-leasing recruitment practices we source the best talent across business functions. As a result, our people become the vessels that carry exceptional value for our clients.
                </p>
                <h3 class="h3 mb-2">Creating Cross-Industry Bridges</h3>
                <p class="p mb-4">
                   Our breadth of solutions leverages our platform of two decades of expansive cross industry experience that helps us solve our clients' biggest operational challenges. Our solutions help companies elevate the chances of success in large transformation, implement strategies for unlocking hidden growth, and enable organizations to thrive through continuous change.
                </p>
            </div>
            <div class="col-md-5 intro-img">
                <img src="img/services-intro.jpg" alt="intro-img" class="img-fluid">
            </div>
        </div>
    </div>
</section>
<!-- ====== //end of intro section ======= -->

<!-- ===== capability section start ===== -->
<section id="capability" class="py-5">
    <div class="container">
        <div class="row ">
            <div class="col-md-12"><h2 class="h2 mb-5">Capabilities</h2></div>

            <div class="col-md-4">
                <figure>
                    <img src="images/capability-1.png" alt="capability" class="img-fluid mb-3" style="    width: 100%;">
                   <a href="https://www.arthurlawrence.net/talent.php"> <figcaption class="mb-2">Talent</figcaption></a>
                </figure>
                <p class="p">
                    Bridging the gap between technology project sponsors and the talent they require to build and drive enterprise-wide technology enablement.
                </p>
            </div>
            <div class="col-md-4">
                <figure>
                    <img src="images/capability-2.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                   <a href="https://www.arthurlawrence.net/consulting.php">  <figcaption class="mb-2">Consulting</figcaption></a>
                </figure>
                <p class="p">
                    Redefining industries through business transformations that enhance efficiency, drive transparency and enable better decision making.
                </p>
            </div>
            <div class="col-md-4">
                <figure>
                    <img src="images/capability-3.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                   <a href="https://www.arthurlawrence.net/operations.php"> <figcaption class="mb-2">Operations</figcaption></a>
                </figure>
                <p class="p">
                    Helping organizations solve their biggest operational challenges through right-shored solutions that focus on outcomes and make it easier to scale as needed.
                </p>
            </div>
           <!--  <div class="col-md-3">
                <figure>
                    <img src="images/capability-4.png" alt="capability" class="img-fluid mb-3">
                    <figcaption class="mb-2">Operational Support </figcaption>
                </figure>
                <p class="p">
                    Enriching the shared services model with the intelligent application of data analytics and operationalization, we bring value to support functions in different services.
                </p>
            </div> -->
        </div>
    </div>
</section>
<!-- ===== // end of capability section  ===== -->

<!-- ==== case study section start ==== -->
<section id="case-study" class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-xl-10 col-md-8 col-sm-12">
                <h2 class="h2">Our Impact</h2>
                <p class="p">Putting business plans to action. Learn how we are leveraging best practices to reshape industries.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5 offset-md-1">
                <div class="card">
                    <img src="img/case-services-1.jpg" class="card-img-top" alt="case study img">
                    <div class="card-body">
                        <h5 class="card-title">Solving the gender pay gap through a decentralized talent economy.</h5>
                        <p class="card-text p mb-4">Representation isn’t enough when it comes to overcoming gender, ethnic and disability gaps
in the modern workplace. According to the World Economic Forum Global Gender Gap Report 2020...</p>
                        <br/><br/>
                        <a href="https://www.arthurlawrence.net/blog/solving-the-gender-pay-gap-through-a-decentralized-talent-economy/" class="card-link"><em>LEARN MORE</em></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 ">
                <div class="card">
                    <img src="img/case-services-2.jpg" class="card-img-top" alt="case study img">
                    <div class="card-body">
                        <h5 class="card-title">Unified customer experience: A winning product strategy</h5>
                        <p class="card-text p mb-4">Businesses can no longer afford a silo-based approach to the buyer’s journey. Discover new applications of the Unified Customer Experience approach in business and technology.</p>
                        <div class="container" style="height: 20px !important;"></div>
                        <a href="https://www.arthurlawrence.net/blog/unified-customer-experience-developing-the-case-for-a-winning-product-strategy/" class="card-link"><em>LEARN MORE</em></a>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- ==== //end of case study section  ==== -->

<!-- ====== Insights section start ===== -->
<!-- <section id="insights" class="py-5">
    <div class="container">
        <div class="row mb-5 py-5">
            <div class="col-xl-10 col-md-8 col-sm-12">
                <h2 class="h1 ">Our Latest Thinking</h2>
                 <p class="p">Thought leadership that touches the intersection point of industry research and industry practice. </p> 
            </div>
        </div>
    </div>
    <div class="container-fluid my-5 no-gutter-vertical">
        <div class="row full-img-row no-gutter-vertical">
            <div class="col-xl-3 col-lg-3 col-md-6 px-0">
                <div class="full-img ">Media Highlights

                    <img src="images/seven-pillar.png" alt="full-img" class="img-fluid">
                    <div class="img-txt">
                        <h4 class="h4">Sustaining your competitive <br/>edge in the talent economy</h4>
                        <p class="p">July 25, 2019</p>
                        <span>Blog</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 px-0">
                <div class="full-img img-2">
                    <img src="images/recognition-red.png" alt="full-img" class="img-fluid">
                    <div class="img-txt">
                        <h4 class="h4">Resumes for robots are getting longer. That's good news</h4>
                        <p class="p">July 25, 2019</p>
                        <span>Blog</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 px-0">
                <div class="full-txt">
                    <div class="img-txt">
                        <h3 class="h3">Unified customer experience: Developing the case for a winning product strategy</h3>
                        <p class="p">July 25, 2019</p>
                        <span>Blog</span>
                         <p class="p">
                            Are headhunters stealing your best people? What to do about it.
                        </p> 
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 px-0">
                <div class="full-img img-3">
                    <img src="images/laptop.png" alt="full-img" class="img-fluid">
                    <div class="img-txt">
                        <h4 class="h4">Xperti <br> Press Release</h4>
                        <p class="p">July 25, 2019</p>
                        <span>Article</span>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

    <!-- insights bottom -->
   <!--  <div class="insights-bottom pt-5">
        <div class="container">
            <div class="row ">
                <div class="col-md-5 mb-5">
                    <img src="images/laptop-bottom.png" alt="laptop" class="img-fluid">
                </div>
                <div class="col-md-7 bottom-txt mt-3">
                    <div class="">
                        <h3 class="h3">What Basic Universal Income Will Mean For Technology Professionals</h3>
                        <p class="p">July 25, 2019</p>
                        <span>Insights</span>
                        <p class="p">
                            Universal Basic Income (UBI) has been a much politicized issue in the recent past. It needn’t be. The debate on fair wages may be as old (and as controversial) as the definition of performance itself.  But what if the safest jobs in technology were the focus of UBI?
                            <a href="https://arthurlawrence.net/blog/what-basic-universal-income-will-mean-for-technology-professionals/" class="card-link"><em>LEARN MORE</em></a>
                        </p>

                    </div>

                </div>
                <div class="col-md-5 mb-5">
                    <img src="images/bulb.png" alt="laptop" class="img-fluid">
                </div>
                <div class="col-md-7 bottom-txt mt-3">
                    <div class="">
                        <h3 class="h3">Resumes For Robots Are Getting Longer, And That’s Good News</h3>
                        <p class="p">July 25, 2019</p>
                        <span>Insights</span>
                        <p class="p">
                            Jobs aren’t being automated, tasks are. What does that spell out a workforce of millions of semi-skilled people?
                            <a href="#" class="card-link"><em>LEARN MORE</em></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->
<!-- ====== end of Insights section ===== -->

<!-- ====== contact form ===== -->
<section id="contact-form" class="">
    <div style="padding-top: 30px;background-color: #F8F8F8; padding-bottom:30px" class="main-container">
                <div class="fl-row-content-wrap vamtam-show-bg-image">
                    <div class="fl-row-content fl-row-fixed-width fl-node-content">
                        <div class="fl-col-group fl-node-59d41a3e7bcca" data-node="59d41a3e7bcca">
                            <div class="fl-col fl-node-59d41a3e7bd11" data-node="59d41a3e7bd11" style="width: 100%;">
                                <div class="fl-col-content fl-node-content vamtam-show-bg-image">
                                        <div class="col-sm-8" style="float:  left;">
                                    <div class="fl-module fl-module-vamtam-heading fl-node-59d41a3e7bd92" data-node="59d41a3e7bd92">
                                        <div class="fl-module-content fl-node-content">
                                            <h2 class="vamtam-heading ">
                                                <span class="vamtam-heading-text" style="color:#2e2e2e !important;">Talk to us or visit us in person</span>
                                            </h2>
                                                <p style="color: black!important;padding-top: 1em">We can make your business better. Get in touch to find out how.</p>
                                        </div>
                                       </div>
                                    </div>
                                    <div class="col-sm-4" style="float:  left;">
                                         <a target="_blank" href="/contact.php"><div class="sim-button button6 mybtnapplynow1" style="    margin-top: 40px;   background:transparent;width: 39%; margin-left: 0px; border: 2px solid #2E2E2E; font-family: 'Montserrat', sans-serif !important;height: 45px;font-size: 13px;line-height: 42px;">
                                            <span>Contact Us</span>
                                        </div></a>
                                    </div>


                                
                                </div>
                            </div>
                       
                        </div>
                    </div>
                </div>
            </div>
</section>
<!-- ======// end of contact form ===== -->

<!-- ==== Media Higlights section start ==== -->
<section id="media" class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-xl-10 col-md-8 col-sm-12">
                <h2 class="h1">Media Highlights</h2>
               <!--  <p class="p">Arthur Lawrence has been in the news (for the right reasons). Find out about our journey in supporting social enterprise, business transformation, technology 2.0 and  more.

                </p> -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-5 offset-md-1">
                <div class="card">
                    <img src="images/businessethics1.png" class="card-img-top" alt="case study img" />
                    <div class="card-body">
                        <h5 class="card-title">Arthur Lawrence Celebrates Global Ethics Day 2019</h5>
                        <p class="card-text p mb-4">As a consulting firm that offers solutions built on the intersection of management and technology, Arthur Lawrence frequently finds business ethics at the center of its internal discourse.</p>
                        <a href="https://arthurlawrence.net/blog/arthur-lawrence-celebrates-global-ethics-day-2019/" class="card-link"><em>LEARN MORE</em></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 ">
                <div class="card">
                    <img src="images/rishi-deep-WiCvC9u7OpE-unsplash.png" class="card-img-top" alt="case study img" />
                    <div class="card-body">
                        <h5 class="card-title">Arthur Lawrence Wins Entrepreneur 360 Award 2019</h5>
                        <p class="card-text p mb-4">In recognition for its robust structures, sound business practices and future-focused approach, Entrepreneur Magazine awarded Arthur Lawrence the Entrepreneur 360 Award 2019 </p>
                        <a href="https://arthurlawrence.net/blog/arthur-lawrence-wins-entrepreneur-360-award-for-2019/" class="card-link"><em>LEARN MORE</em></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- ==== //end of cMedia Higlights section  ==== -->

<!--========= subscrib section start ======== -->
<?php include('include/subscribe.php'); ?>
<section>
    <div class="join-now">

        <div class="col-md-12 row" style="    margin: 0px;padding: 0px;">
               <div class="col-md-6 join-left from-left slide-in" >
                <p style="font-family: 'Montserrat', sans-serif !important; font-size: 45px; color: black !important;"><span style="font-weight: bolder">Join</span><br> Arthur Lawrence</p>
                <p>Arthur Lawrence careers transform talent and potential into global opportunities. Invest your skills in building tomorrow's world. Be part of the future. Apply now at Arthur Lawrence.</p>

                 <div class="wrapper-inner-tab-backgrounds-second mybtnapplynow">
                                <div class="sim-button button6 mybtnapplynow1" style="    margin-top: 40px;    margin-left: 0px; border: 2px solid #2E2E2E; font-family: 'Montserrat', sans-serif !important; width: 71%;height: 45px;font-size: 13px;line-height: 42px;">
                                    <a target="_blank" href="http://jobs.arthurlawrence.net/Jobs/ERP_JobBoard.aspx"> <span>Apply now</span> </a>
                                </div>
                            </div>
            </div>

          <div class="col-md-6 join-img" style="padding: 0px;">
                <img src="  /img/job3-min.jpg" alt="join-img" class="img-fluid">
                <div class="join-hover">
                    <img src="images/andres.png" alt="join-hover img" class="w-25">
                </div>
            </div>

        </div>

    </div>
</section>
<!-- ===== // end of join section ====== -->


<?php
include ('include/footer.php');
?>

