<?php
include ('include/header.php');
?>
<style>
    .img-txt h4{
        color: white;
        font-size: 1.2em;
    }
    #banner::before{
        background: rgba(0, 0, 0, 0) !important;
    }

.h1, h1 {
    font-size: 2rem;
}
p{
        font-size: 1em;
}
ul, li {
    font-size: 16px;
    list-style: disc !imporatant;
}
</style>

<!-- ========= banner section start ======= -->
<section id="banner" style="background-image: url('img/coporate-min.jpg')">
    <div class="bnr-cont">
        <div class="container text-center">
             <h1>Corporate Responsibility</h1>
        </div>
    </div>
</section>
<!-- ========= end of banner section ======= -->

<!-- ====== intro section start  ======= -->
<section id="intro">
    <div class="container">
        <div class="row py-lg-5">
            <div class="col-md-12 intro-txt">
                <p class="p mb-4">
                <h1>Corporate Responsibility</h1>
<p><strong>Fight Hunger</strong></p>
<p>We live in a global society, and we at Arthur Lawrence believe that it is our obligation to give back to that society. The elimination of poverty and hunger are a driving force behind our philanthropy. We are contributing quite heavily in hunger alleviation all over the world. By volunteering in local and international advocacy groups, we are actively involved in outreach programs, helping to feed the less fortunate in third-world countries the world over.</p>
<p><strong>Support Education</strong></p>
<p>Unlocking the resources of the future and deploying those resources on a local level can only be achieved if our citizens are well-educated. Education allows for development and advancement in every level of society. We at Arthur Lawrence believe that education can open doors in underprivileged countries; therefore, our mission is Education for All.</p>
<p>We are working toward equal education on a global scale, as we know that education is an investment in the future of our world. We have contributed to the outreach and educational development in third-world countries, giving those citizens a chance to be more self-sustaining. Our goal is to improve literacy by 7.3% even in the most remote regions of the world. By establishing quality schools with educated leaders in these areas, we are helping to develop the future leaders of our world.</p>
<p><strong>Promoting Health Care</strong></p>
<p>Arthur Lawrence is committed to the belief that a healthier world is a better world. We have a vision of quality healthcare standards being provided to some of the least accessible regions of the world. We are working toward continuous improvement of healthcare facilities in struggling countries.</p>
<p>Our aim is for a better world for all citizens, regardless of race, creed, religion and location. Health is a basic human right. We are striving toward a world where every man, woman and child is able to access quality healthcare. By working proactively with global foundations through research and donations, we are able to provide high-quality healthcare to regions that have gone without for far too long.</p>               
            </div>
            
        </div>
    </div>
</section>
<!-- ====== //end of intro section ======= -->

<!-- ===== capability section start ===== -->

<!-- ===== // end of capability section  ===== -->

<!-- ==== case study section start ==== -->

<!-- ====== contact form ===== -->

<!-- ===== // end of join section ====== -->


<?php
include ('include/footer.php');
?>

