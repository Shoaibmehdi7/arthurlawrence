<?php
include ('include/header.php');
?>

<title> Legal Process Outsourcing</title>
<link rel="canonical" href="https://www.arthurlawrence.net/oracle-netsuite.php" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&display=swap" rel="stylesheet">

<!--RMT 8167-->
<!--     <link href="css/style-inner.css" rel="stylesheet"/>
 --> <link href="css/style2-inner.css" rel="stylesheet"/>
    <!-- <link rel="stylesheet" href="../bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
    <!--RMT5253 -->
    <style type='text/css'>
/* adding style to fix line-height problem in header*/
 #banner::before{
        background-color: transparent;
    }
.footer .footer-height{
    width: 100% !important;
}
body{
    overflow-x: hidden;
}
.col, .col-1, .col-10, .col-11, .col-12, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-auto, .col-lg, .col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-auto, .col-md, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-auto, .col-sm, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-auto, .col-xl, .col-xl-1, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-auto

{
    /*padding-left: 0px;*/
    /*padding-right: 0px;*/
}

@media screen and (min-width: 1000px) {
    ul .tertiary-item a {
        line-height: 1 !important;
    }
}

/* end of line-height problem fix in header */

.adjacent-tiles .my-image-box video.mp4Bg {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 50%;
    transform: translateY(-50%) !important;
}
p.btnsignup a:hover {
    color: #000 !important;
}
@media (max-width: 1024px){
.banner-container img {
    left: 48% !important; 
}
}
.adjacent-tiles .articles {
min-height: 342px;
}
@media (min-width: 320px) and (max-width: 1024px)
        {
             .adjacent-tiles br 
             {
                display: none;
             }
             .adjacent-tiles .cta
             {
               display: block;
               margin-top: 12px;
             }
             #block-header-new #header-topnav li{
                 width:100%;
             }
        } 
         @media (max-width: 1000px){
             #banner {
            height: 45vh;
            background-position: -11.5em 0px !important;
    }
    .headingslide{
            font-size: 1.5em !important;
    }
    .sliderP {
        font-size: 0.8em !important;
    }
    .gw{
        width: 90%;
    }
         } 
</style>
</head>

<body data-spy="scroll" data-offset="0" data-target="#scrollspy" class="">
    
	
	 <div class="container-fluid">
	 	<div  class="row">
	 	 <div class="container-block"  style="float: left;width: 100%;">
	 	 	<section id="banner" style="background-image: url('img/bannerkpo-12.jpg');  
">
    <div class="bnr-cont">
        <div class="container gw">
            <h1  class="headingslide" style="color:black">The Legal Process <br>Landscape</h1>
            <p class="sliderP" style="color:black">Creating new capacities within the services ecosystem <br> with Legal Process Outsourcing (LPO) expertise.</p>
        </div>
    </div>
</section>
	 	 </div>
	 	</div>
	 </div>

	<style type="text/css">
	.innerpage{
		margin-top: 6em;
	}
		.innerpage .maintext{
			    font-weight: 800;
    font-size: 3em;
    line-height: 28px;
    letter-spacing: 3px;

		}
		.adjacent-tiles .my-image-box{
	width: 98%;}

		.innerpage .secondarytext{
			font-size: 1.2em;
    font-weight: 600;
    letter-spacing: 3px;
		}
		.imgtxt
		{
			    font-weight: 500;
    font-size: 1.1em;
    margin-top: 4%;
    float: left;
		}
		.innerpage .row{
			margin: 0px;
		}
	

		.box-txt-head{
		font-weight: 800;    font-size: 1.4em;float: left;

	}
	.box-txt-head-1{
		font-weight: 600;
		    font-size: 2.3em;
	}
	.box-txt-desc{
		     font-weight: 500;
    font-size: 1em;
    margin-top: 1.5em;
float:left; width:100%;
	}
	.horizontalText{
		   background: #ee3429;
    height: 5px;
    float: left;
    z-index: -1;margin-top: -7px;
    width: 100%;
	}

.start-project{
	    width: 100%;
    float: left;
    font-size: 1.99em;
    text-align: center;
    font-weight: 800;
}

.start-desc{
	    width: 100%;
    float: left;
    text-align: center;
    font-size: 0.99em;
    font-weight: 500;
}
.innerpage .row {
	    margin-top: 2em;
}
.startPorjectHr{
	    width: 9.5em;
    background: #ee3429;
    height: 6px;
    float: left;
    position: absolute;
    top: 37px;
    z-index: -1;
    margin-left: -9.3em;
}
.buttonWpra{
	float: left;
	width: 100%;
	text-align: center;
	outline: none;
	transition: .4s all ease-in-out;

}
.buttonWpra button
{
	transition: .4s all ease-in-out;
}
.buttonWpra button:hover{
	box-shadow :#6162633b 1px 0px 20px 8px;
	padding: .9em;
}

.buttonWpra button{
    background-color: #ee3429;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 800;
    font-size: 0.9em;
    margin-top: 2em;
    padding: .8em;
    box-shadow: #6162633b 1px 0px 20px -11px;
}


.innerpage{
	margin-bottom: 5em;
        padding-right: 15px;
    padding-left: 15px;
}

		.ups{
			margin-bottom: 8vw;
    		margin-top: 4vw;
		}
		.box-container{
			    width: 78%;
    float: left;
    margin-left: 10%;
		}
		.zoom-onhover-lift{
			    transition: all .4s ease-in-out;
    -webkit-transition: all .4s ease-in-out;
    -moz-transition: all .4s ease-in-out;
    -o-transition: all .4s ease-in-out;
    -ms-transition: all .4s ease-in-out;
		}
		.zoom-onhover-lift:hover{
		margin-top: 1em;
		margin-left: 1em;
		 }

	</style>
<div class="container-fluid innerpage"> 
	
<div class="row">
	<div class="col-sm-12">
		<div style="margin-bottom:10px" class="maintext">AUGMENTING LEGAL CAPABILITIES </div>
		<div  class="secondarytext">Transformative processes to empower and augment your legal capacity.</div>
	</div>

</div>

<div class="row">
	<div class="col-sm-7 mb-fix">
	
			<img src="/img/legal-kpo.png" style="  width: 96%;"  />
	
	</div>
	<div class="col-sm-5 mb-fix">
		<span class="imgtxt">The right legal talent, knowledge and process expertise come together with the Arthur Lawrence Legal Process Outsourcing (LPO) Service Suite. Offering specialized, focused services in compliance, contract lifecycle management, document management, legal technology consulting and other services that empower clients’ legal function with analytics, research and technology-centered processes, Arthur Lawrence’s LPO function promises strategic inflows via cost arbitrage, efficiency and lean processes. This is legal process outsourcing in its most intelligent form. 


</span>
	</div>
</div>


	
<!-- ===== capability section start ===== -->
<section id="capability" class="py-5">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12"><h2 class="h2 mb-5">Legal Process Outsourcing Service Suite</h2></div>
            <div class="row">
            <div class="col-md-4">
                <figure>
                    <img src="/img/compliance.png" alt="capability" class="img-fluid mb-3" style="    width: 100%;">
                    <figcaption class="mb-2">Compliance </figcaption>
                </figure>
                <p class="p">
                  We secure client interests across a wide spectrum of regulatory issues with our risk management framework.
                </p>
            </div>
            <div class="col-md-4">
                <figure>
                    <img src="/img/contractManagement3.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                    <figcaption class="mb-2">Contract Management	</figcaption>
                </figure>
                <p class="p">
                 Our Contract Lifecycle Management (CLM) solution protects clients from the risk, time, and of drafting and monitoring contracts from scratch. 
                </p>
            </div>
            <div class="col-md-4">
                <figure>
                    <img src="/img/documentManagement1.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                    <figcaption class="mb-2">Document Management</figcaption>
                </figure>
                <p class="p">
                
Transact swiftly and securely. We offer a secure, comprehensive system for document management designed for transparency and fortified workflows. 
 
                </p>
            </div>
            </div>
            
            <div class="row">
            
            <div class="col-md-4">
                <figure>
                    <img src="/img/legaloperations1.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                    <figcaption class="mb-2">Legal Operations Optimization </figcaption>
                </figure>
                <p class="p">
                 Engage our legal advisory services to manage process design, benchmarking and roadmap setting to optimize internal processes. 
                </p>
            </div>
            <div class="col-md-4">
                <figure>
                    <img src="/img/legaltalent1.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                    <figcaption class="mb-2">Legal Talent Sourcing</figcaption>
                </figure>
                <p class="p">
                   Building on a database of two decades’ of recruitment analytics, we ensure a strong pipeline of legal talent for your legal team. 
 	
                </p>
            </div>
            <div class="col-md-4">
                <figure>
                    <img src="/img/legaltechnology.png" alt="capability" class="img-fluid mb-3"  style="    width: 100%;">
                    <figcaption class="mb-2">Legal Technology Consulting </figcaption>
                </figure>
                <p class="p">
                Our LPO services facilitate clients with advisory services on areas such as blockchain, cryptocurrency, new cyberlaws, carbon stocks, M&As and more.




                </p>
            </div>
            </div>
           <!--  <div class="col-md-3">
                <figure>
                    <img src="images/capability-4.png" alt="capability" class="img-fluid mb-3">
                    <figcaption class="mb-2">Operational Support </figcaption>
                </figure>
                <p class="p">
                    Enriching the shared services model with the intelligent application of data analytics and operationalization, we bring value to support functions in different services.
                </p>
            </div> -->
        </div>
    </div>
</section>
<!-- ===== // end of capability section  ===== -->


<div class="row ">
	<div class="ups">
	<div class="col-sm-4">
		<div class="box-container">
		<div class="box-txt-head">Powered By Technology<span class="horizontalText"></span></div>
		<div class="box-txt-desc">
		Depend on digitization for all the right reasons. We deploy intelligent dashboards that enhance the negotiation and decision-making capacity of your legal team. Our data visualization tools also support collaboration between stakeholders, improve transaction time, and measurably reduce delays and error rates. 
		</div>
		</div>
	</div>
	<div class="col-sm-4">
		<div class="box-container">
		<div class="box-txt-head">Centered On Security<span class="horizontalText"></span></div>
		<div class="box-txt-desc">
		Experience the benefits of our LPO Services’ robust cybersecurity infrastructure.  Workflows ensure client visibility across each process, while an experienced, certified cybersecurity team monitors deployment of cybersecurity tools and proactively undertakes all measures to safeguard data and systems.
		</div>
	</div>
	</div>
	<div class="col-sm-4">
		<div class="box-container">
		<div class="box-txt-head">Comprehensive Offering<span class="horizontalText"></span></div>
		<div class="box-txt-desc">
From contract management and legal sourcing to strategic aspects such as rebuilding the legal function of your team, we have the expertise and the capabilities to help you get more performance out of your business, while ensuring full compliance with applicable regulation and governance.
		</div>
	</div>
	</div>
</div>
</div>

<div class="row articles" >
				    <div class="col-sm-8 ">
				        <div class="adjacent-tiles zoom-onhover">
				            <div class="articles" data-tile-height="684px">
				                <!--  CARD TYPES -->
				                <div class="my-image-box" data-card-type="Image" style="background-image: url(/img/supplychain232.jpg);">

				                </div>
				                <div class="card card-container fixed-width transparent-opacity cardh-left cardv-middle" data-cardcolor="to top, white, white " data-card-width="fixed-width">
				                    <p class="cardTitle ucase with-animation">
				                        <a href="index.html" title="">BLOG</a>
				                    </p>
				                    <div class="card-wrapper">
				                        <h2 class="headline"><a href="https://www.arthurlawrence.net/blog/cloud-storage-and-business-recovery-how-to-protect-your-data-in-case-of-the-unforeseen/" target=”_blank” title="">Cloud Storage and Business Recovery: How to Protect your Data in Case of the Unforeseen</a></h2>
				                        <p class="subHeadline"><a href="https://www.arthurlawrence.net/blog/cloud-storage-and-business-recovery-how-to-protect-your-data-in-case-of-the-unforeseen/" target=”_blank” title="">In today’s business world, information and data significantly impact business growth and continuity. Loss of data is a risk small and medium-sized businesses cannot afford to take.</a></p>
				                    </div>
				                </div>
				            </div>
				        </div>
				    </div>
				    <div class="col-sm-4 ">

				        <div class="adjacent-tiles zoom-onhover">

				            <div class="articles" data-tile-height="684px">

				                <!--  CARD TYPES -->
				                <div class="my-image-box" style="background-image: url(/img/erporcustom.jpg);">
				                    <!--  Mp4 Video -->
				                </div>
				                <div class="card card-container fixed-width transparent-opacity cardh-middle cardv-middle" data-cardcolor="to top, white, white " data-card-width="fixed-width">
				                    <p class="cardTitle ucase with-animation">
				                        <a href="https://vibgyormobileapps.com/albeta/how-the-financial-industry-is-responding/" title="Technology Vision 2018: Intelligent enterprise unleashed">BLOG</a>
				                    </p>
				                    <div class="card-wrapper">
				                        <h2 class="headline"><a href="https://www.arthurlawrence.net/blog/immutable-nodes-why-blockchain-still-doesnt-have-the-answer-to-complete-privacy/" target=”_blank” title="Technology Vision 2018: Intelligent enterprise unleashed">Immutable Nodes: Why Blockchain Still Doesn’t Have The Answer To Complete Privacy</a></h2>
				                        <p class="subHeadline"><a href="https://www.arthurlawrence.net/blog/immutable-nodes-why-blockchain-still-doesnt-have-the-answer-to-complete-privacy/"  target=”_blank” title="Technology Vision 2018: Intelligent enterprise unleashed">With several parallel shifts in global politics, technology and industry: From...
 
</a></p>

				                    </div>
				                </div>
				            </div>
				        </div>

				    </div>
</div>


<!-- <div class="row">
	<div class="ups">
	<div class="col-sm-4">
		<div class="box-container">
		<div class="box-txt-head">Shared Service Gains<span class="horizontalText"></span></div>
		<div class="box-txt-desc">
	Experience strategic savings by engaging expert, well-equipped managed services security team and/or a Fractional Chief Information Security Officer (CISO). 
		</div>
	</div>
	</div>
	<div class="col-sm-4">
		<div class="box-container">
		<div class="box-txt-head">Data Policy Management<span class="horizontalText"></span></div>
		<div class="box-txt-desc">
		Proactive, thorough, and closely tailored to meet your specific business needs. That is how our cybersecurity team leads data policy—covering all fronts from protection, reporting, storage and oversights management.
		</div>
	</div>
	</div>
	<div class="col-sm-4">
		<div class="box-container">
		<div class="box-txt-head">360&deg;  Cybersecurity Methodology<span class="horizontalText"></span></div>
		<div class="box-txt-desc">
Each member of the Arthur Lawrence cybersecurity team is a certified, experienced professional who brings strategic subject matter expertise, as well as a tactical approach to cybersecurity challenges.
		</div>
	</div>
	</div> -->
</div>
</div>

<style type="text/css">
	
</style>


</div>

	
<!-- ==== Media Higlights section start ==== -->
<section id="media" class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-xl-10 col-md-8 col-sm-12">
                <h2 class="h1">Media Highlights</h2>
               <!--  <p class="p">Arthur Lawrence has been in the news (for the right reasons). Find out about our journey in supporting social enterprise, business transformation, technology 2.0 and  more.

                </p> -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-5 offset-md-1">
                <div class="card">
                    <img src="images/businessethics1.png" class="card-img-top" alt="case study img" />
                    <div class="card-body">
                        <h5 class="card-title">Arthur Lawrence Celebrates Global Ethics Day 2019</h5>
                        <p class="card-text p mb-4">As a consulting firm that offers solutions built on the intersection of management and technology, Arthur Lawrence frequently finds business ethics at the center of its internal discourse.</p>
                        <a href="https://arthurlawrence.net/blog/arthur-lawrence-celebrates-global-ethics-day-2019/" class="card-link"><em>LEARN MORE</em></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 ">
                <div class="card">
                    <img src="images/rishi-deep-WiCvC9u7OpE-unsplash.png" class="card-img-top" alt="case study img" />
                    <div class="card-body">
                        <h5 class="card-title">Arthur Lawrence Wins Entrepreneur 360 Award 2019</h5>
                        <p class="card-text p mb-4">In recognition for its robust structures, sound business practices and future-focused approach, Entrepreneur Magazine awarded Arthur Lawrence the Entrepreneur 360 Award 2019 </p>
                        <a href="https://arthurlawrence.net/blog/arthur-lawrence-wins-entrepreneur-360-award-for-2019/" class="card-link"><em>LEARN MORE</em></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- ==== //end of cMedia Higlights section  ==== -->		

<!--========= subscrib section start ======== -->
<?php include('include/subscribe.php'); ?>
<section>
    <div class="join-now">

        <div class="col-md-12 row" style="    margin: 0px;padding: 0px;">
            <div class="col-md-6 join-left from-left slide-in" >
                <p style="font-family: 'Montserrat', sans-serif !important; font-size: 45px; color: black !important;"><span style="font-weight: bolder">Join</span><br> Arthur Lawrence</p>
                <p>Arthur Lawrence careers transform talent and potential into global opportunities. Invest your skills in building tomorrow's world. Be part of the future. Apply now at Arthur Lawrence.</p>

                 <div class="wrapper-inner-tab-backgrounds-second mybtnapplynow">
                                <div class="sim-button button6 mybtnapplynow1" style="    margin-top: 40px;    margin-left: 0px; border: 2px solid #2E2E2E; font-family: 'Montserrat', sans-serif !important; width: 71%;height: 45px;font-size: 13px;line-height: 42px;">
                                    <a target="_blank" href="http://jobs.arthurlawrence.net/Jobs/ERP_JobBoard.aspx"> <span>Apply now</span> </a>
                                </div>
                            </div>
            </div>

          <div class="col-md-6 join-img" style="padding: 0px;">
                <img src="  /img/person112.jpg" alt="join-img" class="img-fluid">
                <div class="join-hover">
                    <img src="images/andres.png" alt="join-hover img" class="w-25">
                </div>
            </div>

        </div>

    </div>
</section>
<!-- ===== // end of join section ====== -->

<?php
include ('include/footer.php');
?>

<script>
$( document ).ready(function() {
      $('#head-logo').css('filter','brightness(0.35)');
         $('#mainbodyid').addClass('mythemedark');
       // $('.menu-hamburger').css("background-color", "#000" );
       $('.global-primary-nav-r3 .primary-navigation>.nav-list>.nav-item>a, .global-primary-nav-r3 .local-navigation>.nav-list>.nav-item>a').css("color",'#2e2e2e');
});
</script>